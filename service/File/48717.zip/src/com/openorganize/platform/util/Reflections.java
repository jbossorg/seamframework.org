package com.openorganize.platform.util;

import java.beans.Introspector;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@Name("reflections")
@Scope(ScopeType.APPLICATION)
public class Reflections extends org.jboss.seam.util.Reflections {

	/** Convert a constant name like "EAT_POTATOES" to "Eat Potatoes" */
	public static String constantToTitleCase(String constantName) {
		StringBuffer result = new StringBuffer();
		final int len = constantName.length();
		boolean expectCapital = true;
		for (int pos = 0; pos < len; pos++) {
			char ch = constantName.charAt(pos);
			if (ch == '_') {
				result.append(' ');
				expectCapital = true;
			} else if (!Character.isLetter(ch)) {
				result.append(ch);
			} else if (expectCapital) {
				result.append(Character.toUpperCase(ch));
				expectCapital = false;
			} else {
				result.append(Character.toLowerCase(ch));
			}
		}
		return result.toString();
	}

	/** Identify the boxed class that corresponds to the given primitive class */
	public static Class getBoxedClass(Class primitive) {
		if (byte.class.equals(primitive)) {
			return java.lang.Byte.class;
		} else if (short.class.equals(primitive)) {
			return java.lang.Short.class;
		} else if (int.class.equals(primitive)) {
			return java.lang.Integer.class;
		} else if (long.class.equals(primitive)) {
			return java.lang.Long.class;
		} else if (float.class.equals(primitive)) {
			return java.lang.Float.class;
		} else if (double.class.equals(primitive)) {
			return java.lang.Double.class;
		} else if (boolean.class.equals(primitive)) {
			return java.lang.Boolean.class;
		} else if (char.class.equals(primitive)) {
			return java.lang.Character.class;
		} else {
			throw new RuntimeException("Class does not appear to be primitive: "
					+ primitive.getCanonicalName());
		}
	}

	/**
	 * Find all annotations declared directly on the given property within the
	 * given class, including any annotations on the field or accessor method.
	 */
	public static Collection<Annotation> getDeclaredAnnotations(final Class beanClass,
			final String property) {
		final Collection<Annotation> annos = new ArrayList<Annotation>();
		final String capitalProperty = Character.toUpperCase(property.charAt(0))
				+ property.substring(1);

		// field
		try {
			for (Annotation anno : beanClass.getDeclaredField(property).getDeclaredAnnotations()) {
				annos.add(anno);
			}
		} catch (NoSuchFieldException iae) {
		}

		// get method
		try {
			for (Annotation anno : beanClass.getDeclaredMethod("get" + capitalProperty)
					.getDeclaredAnnotations()) {
				annos.add(anno);
			}
		} catch (NoSuchMethodException iae) {
		}

		// is method
		try {
			for (Annotation anno : beanClass.getDeclaredMethod("is" + capitalProperty)
					.getDeclaredAnnotations()) {
				annos.add(anno);
			}
		} catch (NoSuchMethodException iae) {
		}

		return annos;
	}

	/** This method is derived from Seam's getGetterMethod. It fixes JBSEAM-3392. */
	public static Method getGetterMethod(Class clazz, String name) {
		Method[] methods = clazz.getMethods();
		for (Method method : methods) {
			String methodName = method.getName();
			if (method.getParameterTypes().length == 0) {
				if (methodName.matches("^get.*")
						&& Introspector.decapitalize(methodName.substring(3)).equals(name)) {
					return method;
				}
				if (methodName.matches("^is.*")
						&& Introspector.decapitalize(methodName.substring(2)).equals(name)) {
					return method;
				}
			}
		}
		throw new IllegalArgumentException("no such getter method: " + clazz.getName() + '.' + name);
	}

	/**
	 * Locates an annotation for a property. The annotation may be applied to the
	 * getter or the field.
	 * 
	 * @param beanClass The class containing the property
	 * @param property The name of the property
	 * @param annoClass The class of the desired annotation
	 * @return An instance of annoClass. If none is available, then null (like java.lang.Class.getAnnotation).
	 */
	public static <A extends Annotation> A getPropertyAnnotation(final Class beanClass,
			final String property, final Class<A> annoClass) {

		// Subclasses may meaningful override accessor and replace the original
		// annotation, but subclasses may not meaningfully override the field.
		// Consequently, if the subclass wants polymorphism, it can only
		// express this by annotating the accessor in the subclass.

		try {
			A anno = getGetterMethod(beanClass, property).getAnnotation(annoClass);
			if (anno != null) {
				return anno;
			}
		} catch (IllegalArgumentException iae) {

		}

		try {
			A anno = getField(beanClass, property).getAnnotation(annoClass);
			if (anno != null) {
				return anno;
			}
		} catch (IllegalArgumentException iae) {

		}

		return null;
	}

	public static Class getPropertyClass(final Class beanClass, final String property) {
		return getGetterMethod(beanClass, property).getReturnType();
	}

	public static Class getPropertyClass(final String className, final String name)
			throws ClassNotFoundException {
		return getPropertyClass(Class.forName(className), name);
	}

	/** Determine whether a property is defined for the given class */
	public static boolean hasProperty(final Class clazz, final String property) {
		final String capitalProperty = Character.toUpperCase(property.charAt(0))
				+ property.substring(1);

		try {
			clazz.getMethod("get" + capitalProperty);
			return true;
		} catch (NoSuchMethodException iae) {

		}

		try {
			clazz.getMethod("is" + capitalProperty);
			return true;
		} catch (NoSuchMethodException iae) {
		}

		return false;
	}
}
