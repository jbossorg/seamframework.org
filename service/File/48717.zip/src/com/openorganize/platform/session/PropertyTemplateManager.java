package com.openorganize.platform.session;

import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Logger;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.log.Log;
import org.jboss.seam.util.Resources;

import com.openorganize.platform.PropertyTemplate;
import com.openorganize.platform.util.Reflections;

@Name("propertyTemplateManager")
@Scope(ScopeType.APPLICATION)
@SuppressWarnings("serial")
public class PropertyTemplateManager implements Serializable {
	@Logger
	Log log;

	private String basePath = "/WEB-INF/property";

	private String defaultTemplate = "/default.xhtml";

	private boolean cacheEnabled = false;

	// Perhaps ConcurrentHashMap? Need to see which is better for read-heavy
	// usage.
	// Note that competing writes should be safe because concurrent writers
	// should produce the same value.
	private Map<Object, String> templatePathCache = new HashMap<Object, String>();

	/* template-management utilities */

	protected Object createTemplateCacheKey(final String beanClass, final String property,
			final String viewType) {
		return beanClass + "." + property + "-" + viewType;
	}

	protected String createTemplatePath(final String javaCanonicalName, final String viewType) {
		return basePath + "/" + javaCanonicalName.replaceAll("\\.", "/") + "-" + viewType
				+ ".xhtml";
	}

	protected boolean templateExists(String path) {
		boolean result = (null != Resources.getResource(path, null));
		if (log.isDebugEnabled()) {
			log.debug("templateExists: " + path + " => " + result);
		}
		return result;
	}

	/**
	 * Locate the most specific HTML/JSF/Facelets template for
	 * displaying a bean property. This method implements
	 * memoization/caching to improve performance... although, in
	 * retrospect, I wrote the memoization without knowing anything
	 * about JSF/Facelets lifecycle, so it may be entirely unnecessary.
	 * 
	 * @param beanClass
	 *            The canonical name of the Java class of which the bean is an
	 *            instance
	 * @param property
	 *            The name of the property for which we want a template
	 * @param viewType
	 *            The type of view which we need for this property (e.g. edit,
	 *            display)
	 * @return The full path to an HTML/JSF/Facelets template.
	 */
	public String getTemplate(final String beanClass, final String property, final String viewType) {
		if (cacheEnabled) {
			final Object templatePathCacheKey = createTemplateCacheKey(beanClass, property,
					viewType);
			String result = templatePathCache.get(templatePathCacheKey);
			if (result == null) {
				result = findTemplate(beanClass, property, viewType);
				if (result == null) {
					result = basePath + defaultTemplate;
				}
				templatePathCache.put(templatePathCacheKey, result);
			}
			return result;
		} else {
			String result = findTemplate(beanClass, property, viewType);
			return result != null ? result : (basePath + defaultTemplate);
		}
	}

	/**
	 * Un-memoized/un-cached method which locates the most specific
	 * HTML/JSF/Facelets template for displaying a bean property.
	 * 
	 * @param beanClassName
	 * @param property
	 * @param viewType
	 * @return The full path to an HTML/JSF/Facelets template. Null if
	 *         unavailable.
	 */
	protected String findTemplate(final String beanClassName, final String property,
			final String viewType) {
		if (log.isDebugEnabled()) {
			log.debug("findTemplate: " + beanClassName + "," + property + "," + viewType);
		}

		String result = null;
		try {
			Class beanClass = Class.forName(beanClassName);

			// there may be a template defined in the property or a superclass
			if (result == null) {
				result = findTemplateByProperty(beanClass, property, viewType);
			}

			// There may be a template available based on the type of the
			// property. This is the most generic way to choose a template.
			if (result == null) {
				try {
					Class returnType = Reflections.getGetterMethod(beanClass, property)
							.getReturnType();
					result = findTemplateByReturnType(returnType, viewType);
				} catch (IllegalArgumentException iae) {
					// failed to find method
				}

			}
		} catch (ClassNotFoundException cnfe) {
			log.error("Cannot load property template for invalid class: " + beanClassName);
			// stay null
		}

		return result;
	}

	/**
	 * 
	 * @param beanClass
	 * @param property
	 * @param viewType
	 * @return The full path to an HTML/JSF/Facelets template. Null if
	 *         unavailable.
	 */
	protected String findTemplateByReturnType(final Class returnType, final String viewType) {
		Class clazz = returnType;

		// Perform the template lookup based on the boxed type rather than the
		// primitive type.
		if (clazz.isPrimitive()) {
			clazz = Reflections.getBoxedClass(clazz);
		}

		while (!Object.class.equals(clazz)) {
			String templatePath = createTemplatePath(clazz.getCanonicalName(), viewType);
			if (templateExists(templatePath)) {
				return templatePath;
			} else {
				clazz = clazz.getSuperclass();
			}
		}

		// one more test! see if java.lang.Object has a template
		String templatePath = createTemplatePath(clazz.getCanonicalName(), viewType);
		if (templateExists(templatePath)) {
			return templatePath;
		}
		
		return null;

	}

	/**
	 * 
	 * @param beanClass
	 * @param property
	 * @param viewType
	 * @return The full path to an HTML/JSF/Facelets template. Null if
	 *         unavailable.
	 */
	protected String findTemplateByProperty(final Class beanClass, final String property,
			final String viewType) {
		if (log.isDebugEnabled()) {
			log.debug("findTemplateByProperty: " + beanClass.getCanonicalName() + "," + property
					+ "," + viewType);
		}

		if (Object.class.equals(beanClass) || !Reflections.hasProperty(beanClass, property)) {
			if (log.isDebugEnabled()) {
				log.debug("findTemplateByProperty: " + beanClass.getCanonicalName()
						+ " does not have property=" + property);
			}
			return null;
		} else {

			String result = null;

			/*
			 * // check for @PropertyTemplate
			 * 
			 * if (propertyTemplate.id())
			 * 
			 * result = createTemplatePath(propertyTemplate.id(), viewType)
			 * 
			 * else if (propertyTemplate.aliasClass() &&
			 * propertyTemplate.aliasProperty())
			 * 
			 * result = findTemplate(
			 * Class.forName(propertyTemplate.aliasClass()),
			 * propertyTemplate.aliasProperty(), viewType );
			 */

			// there may be an override directing us to look at a special template file
			if (result == null) {
				PropertyTemplate pt = Reflections.getPropertyAnnotation(beanClass, property, PropertyTemplate.class);
				if (pt != null && pt.id() != null && !"".equals(pt.id())) {
					String path = createTemplatePath(pt.id(), viewType);
					if (templateExists(path)) {
						result = path;
					}
				}
			}
			
			// there may be a template specifically for this property
			if (result == null) {
				String path = createTemplatePath(beanClass.getCanonicalName() + "." + property,
						viewType);
				if (templateExists(path)) {
					result = path;
				}
			}

			// there may be a template for one of the annotations
			if (result == null) {
				Iterator<Annotation> iter = Reflections.getDeclaredAnnotations(beanClass, property)
						.iterator();
				while (result == null && iter.hasNext()) {
					Annotation anno = iter.next();
					final String annoPath = createTemplatePath(anno.annotationType()
							.getCanonicalName(), viewType);
					if (templateExists(annoPath)) {
						result = annoPath;
					}
				}
			}

			// if this property is inherited, then the parent class may have a
			// template
			if (result == null) {
				if (log.isDebugEnabled()) {
					log.debug("findTemplateByProperty: superclass of "
							+ beanClass.getCanonicalName() + " is "
							+ beanClass.getSuperclass().getCanonicalName());
				}
				result = findTemplateByProperty(beanClass.getSuperclass(), property, viewType);
			}

			if (log.isDebugEnabled()) {
				log.debug("findTemplateByProperty: Template for (" + beanClass.getCanonicalName()
						+ "," + property + "," + viewType + ") is [" + result + "]");
			}
			return result;
		}
	}

	/* boiler-plate */

	public synchronized void clear() {
		templatePathCache.clear();
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

	public String getDefaultTemplate() {
		return defaultTemplate;
	}

	public void setDefaultTemplate(String defaultTemplate) {
		this.defaultTemplate = defaultTemplate;
	}

	public boolean isCacheEnabled() {
		return cacheEnabled;
	}

	public void setCacheEnabled(boolean cacheEnabled) {
		if (this.cacheEnabled != cacheEnabled) {
			this.cacheEnabled = cacheEnabled;
			clear();
		}
	}
}
